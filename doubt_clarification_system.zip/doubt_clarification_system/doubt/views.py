import json
import requests
from django.shortcuts import get_object_or_404, render
def login(request,token):
	res = requests.post(url='https://serene-wildwood-35121.herokuapp.com/oauth/getDetails', data={
    'token': token,
    'secret': 'eb130fdfd5b678fdd19e4f2c8ab7e4bace85927a538caa34b7a7efb6ddc2f65b0c086bc3753abfe7c726c2e60e651a52a2995d596088de2d364e61e40453a504'
})
	res = json.loads(res.content)
	email = res['student'][0]['Student_Email']
	#print(email)
	if(email):
		return render(request,'polls/index.html')

