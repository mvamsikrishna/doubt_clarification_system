from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import generic
from django.utils import timezone
from .models import  Question,Answer

def login(request):
	return render(request,'polls/login.html')

def index(request):
	return render(request,'polls/index.html')

def subject(request):
	return render(request,'polls/courses.html')


def trendingquestions(request):
	if request.method=='POST':
		if request.POST['guess'] == 'answer':
			print(request.POST['answ'])
			ans = Answer()
			ans.answer = request.POST['answ']
			q = Question.objects.all()
			val = request.POST['write']
			
			for i in q:
				if i.question_text == val:
					ans.answer_id = i.question_id
					break
			#ans.answer_id = 45
			#ans.answer = request.POST['answer']
			ans.save()
	
	#vacancies=Question.objects.all()
	#context={"vacancies":vacancies}
	#return render(request,'vacancies.html', context)
		return render(request,'polls/trendingquestions.html')
	else:
		context = {'question_objs' : Question.objects.all() , 'answer_objs':Answer.objects.all() }
		return render(request,'polls/trendingquestions.html',context)
		




def digi(request):
	return render(request,'polls/digi.html')

def ls(request):
	return render(request,'polls/LS.html')

def vlsi(request):
	return render(request,'polls/vlsi.html')

def dsp(request):
	return render(request,'polls/dsp.html')

def users(request):
	return render(request,'polls/users.html')

def selectedtopic(request):
	return render(request,'polls/selectedtopic.html')

def selectedtopic1(request):
	return render(request,'polls/selectedtopic1.html')

def selectedtopic2(request):
	return render(request,'polls/selectedtopic2.html')

def selectedtopic3(request):
	return render(request,'polls/selectedtopic3.html')


def viewqa(request):
	if request.method=='POST':
		print(request.POST['guess'])
		if request.POST['guess'] == 'question':

			vac= Question()
			#vac.question_id=request.POST['question_id']
			vac.question_course = request.POST['course1']
			vac.question_text=request.POST['question_text']
			
			vac.save()
		if request.POST['guess'] == 'answer':
			print(request.POST['answ'])
			ans = Answer()
			ans.answer = request.POST['answ']
			q = Question.objects.all()
			val = request.POST['write']
			
			for i in q:
				if i.question_text == val:
					ans.answer_id = i.question_id
					break
			#ans.answer_id = 45
			#ans.answer = request.POST['answer']
			ans.save()
	
	#vacancies=Question.objects.all()
	#context={"vacancies":vacancies}
	#return render(request,'vacancies.html', context)
		return render(request,'polls/viewqa.html')
	else:
		context = {'question_objs' : Question.objects.all() , 'answer_objs':Answer.objects.all() }
		return render(request,'polls/viewqa.html',context)
		
def viewqa1(request):
	if request.method=='POST':
		print(request.POST['guess'])
		if request.POST['guess'] == 'question':

			vac= Question()
			#vac.question_id=request.POST['question_id']
			vac.question_course = request.POST['course2']
			vac.question_text=request.POST['question_text']
			#vac.technical_skills=request.POST['pub_date']
			#vac.other_skills=request.POST['other_skills']
			#vac.expected_salary=request.POST['expected_salary']
			vac.save()
		if request.POST['guess'] == 'answer':
			print(request.POST['answ'])
			ans = Answer()
			ans.answer = request.POST['answ']
			q = Question.objects.all()
			val = request.POST['write']
			
			for i in q:
				if i.question_text == val:
					ans.answer_id = i.question_id
					break
			#ans.answer_id = 45
			#ans.answer = request.POST['answer']
			ans.save()
	
	#vacancies=Question.objects.all()
	#context={"vacancies":vacancies}
	#return render(request,'vacancies.html', context)
		return render(request,'polls/viewqa1.html')
	else:
		context = {'question_objs' : Question.objects.all() , 'answer_objs':Answer.objects.all() }
		return render(request,'polls/viewqa1.html',context)
		
def viewqa2(request):
	if request.method=='POST':
		print(request.POST['guess'])
		if request.POST['guess'] == 'question':

			vac= Question()
			#vac.question_id=request.POST['question_id']
			vac.question_course = request.POST['course3']
			vac.question_text=request.POST['question_text']
			#vac.technical_skills=request.POST['pub_date']
			#vac.other_skills=request.POST['other_skills']
			#vac.expected_salary=request.POST['expected_salary']
			vac.save()
		if request.POST['guess'] == 'answer':
			print(request.POST['answ'])
			ans = Answer()
			ans.answer = request.POST['answ']
			q = Question.objects.all()
			val = request.POST['write']
			
			for i in q:
				if i.question_text == val:
					ans.answer_id = i.question_id
					break
			#ans.answer_id = 45
			#ans.answer = request.POST['answer']
			ans.save()
	
	#vacancies=Question.objects.all()
	#context={"vacancies":vacancies}
	#return render(request,'vacancies.html', context)
		return render(request,'polls/viewqa2.html')
	else:
		context = {'question_objs' : Question.objects.all() , 'answer_objs':Answer.objects.all() }
		return render(request,'polls/viewqa2.html',context)
		



def viewqa3(request):
	if request.method=='POST':
		print(request.POST['guess'])
		if request.POST['guess'] == 'question':

			vac= Question()
			#vac.question_id=request.POST['question_id']
			vac.question_course = request.POST['course4']
			vac.question_text=request.POST['question_text']
			#vac.technical_skills=request.POST['pub_date']
			#vac.other_skills=request.POST['other_skills']
			#vac.expected_salary=request.POST['expected_salary']
			vac.save()
		if request.POST['guess'] == 'answer':
			print(request.POST['answ'])
			ans = Answer()
			ans.answer = request.POST['answ']
			q = Question.objects.all()
			val = request.POST['write']
			
			for i in q:
				if i.question_text == val:
					ans.answer_id = i.question_id
					break
			#ans.answer_id = 45
			#ans.answer = request.POST['answer']
			ans.save()
	
	#vacancies=Question.objects.all()
	#context={"vacancies":vacancies}
	#return render(request,'vacancies.html', context)
		return render(request,'polls/viewqa3.html')
	else:
		context = {'question_objs' : Question.objects.all() , 'answer_objs':Answer.objects.all() }
		return render(request,'polls/viewqa3.html',context)
		



